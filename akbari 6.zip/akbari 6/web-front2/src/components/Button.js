export function Button({ type = "primary", text }) {
  const className = type === "primary" ? "button-primary" : "button-secondary";
  return `<button class="${className}">${text}</button>`;
}